<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
    // 指令定义
    'commands' => [
        'runx' => 'app\main', 'swoole2' => 'app\common\mainx','main22' => 'app\common\mainx',
        'keywdReqHdlr' => 'app\common\keywdReqHdlr', 'testx' => 'app\common\testCls',
        
    ],
];
