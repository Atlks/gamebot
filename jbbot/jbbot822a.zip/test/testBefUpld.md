
unit test dwijyo 
unitest bets.fmt 

imotest hdr2 no putput char

php  public/hd2test.php

php app/main_cmd.php