<?php
//   6599269003:AAHW6kAh3Cy28vT4NuzQIkU4sISM3iFi-OA      ssc2024_bot  test ssc bot
//  C:\phpstudy_pro\Extensions\php\php8.0.2nts\php.exe app/lotrySsc.php
//   特码球玩法=\d\/\d\/\d+,特码球大小单双玩法=\d+[大|小|单|双]\d+,和值大小单双玩法=和[大|小|单|双]\d+,龙虎和玩法=[龙|虎|和]\d+,前后三玩法=[前|后][豹|顺|对|半|杂]\d+
//1/1/1
 

//C:\phpstudy_pro\Extensions\php\php8.0.2nts\php.exe test/lotrySscTest.php 
require_once  __DIR__ . "/../app/lotrySsc.php";
$keywd=   $_SERVER['argv'][1];
var_dump(getWefa($keywd));
die();
//var_dump(join(" ",getKaijNumArr_hezDasyods("41278") ));

 

//var_dump(dwijyo("和100",   "01690"));

$blkHash1236 = " 0x60d94a8232c1bc35fd15467cda7ea578861242433611cf50099fa73943ae8c1a";
//var_dump(getKaijNumFromBlkhash($blkHash1236));
//var_dump(getKaijNumFly_longhuHaeWefa("01690"));



  