<?php

$xxx=get_included_files();

$xxx=get_included_files();
reqrOnce(__DIR__."/a.php")  ;
$xxx=get_included_files();