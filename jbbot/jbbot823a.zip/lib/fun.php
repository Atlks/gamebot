<?php


function function_existsx($obj)
{
    if(is_array($obj))
        return false;

    return function_exists($obj);

}