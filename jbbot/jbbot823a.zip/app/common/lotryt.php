<?php
namespace think;

use app\common\lotrySpltrCls;
require __DIR__ . '/../../vendor/autoload.php';
new App();



$rzt717= lotrySpltrCls::msgHdlr("a123操200");
$rzt717= lotrySpltrCls::msgHdlr("a大小单双.100");

//$rzt717= lotrySpltrCls::tmqwfabc1200zhms("abc1.200");
$rzt717=1;