
<?php

//  C:\phpstudy_pro\Extensions\php\php8.0.2nts\php.exe C:\shnkprj_git\jbbot\config\swo.php


//echo   parse_ini_file(__DIR__."/../.env")['swoole_port'];